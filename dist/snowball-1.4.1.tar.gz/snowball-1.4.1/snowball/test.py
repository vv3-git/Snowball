def test():
    print("ALL set! Welcome to snowball")